using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Sessions.Models;



namespace Sessions.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }


    [HttpGet]
    [Route("")]
    public ViewResult Index()
    {
        return View();
    }


    [HttpPost("process")]
    public IActionResult Process(User newUser)
    {
        HttpContext.Session.SetInt32("Count", 22);
        if (!ModelState.IsValid)
        {
            return View("Index");
        }
        HttpContext.Session.SetString("Name", newUser.Name);
        HttpContext.Session.SetInt32("Count", 22);
        return RedirectToAction("Dashboard");
    }


    [HttpPost("add")]
    public IActionResult Add()
    {
        int currentCount = HttpContext.Session.GetInt32("Count") ?? 22;
        HttpContext.Session.SetInt32("Count", currentCount + 1);
        return RedirectToAction("Dashboard");
    }


    [HttpPost("subtract")]
    public IActionResult Subtract()
    {
        int currentCount = HttpContext.Session.GetInt32("Count") ?? 22;
        HttpContext.Session.SetInt32("Count", currentCount - 1);
        return RedirectToAction("Dashboard");
    }


    [HttpPost("multiply")]
    public IActionResult Multiply()
    {
        int currentCount = HttpContext.Session.GetInt32("Count") ?? 22;
        HttpContext.Session.SetInt32("Count", currentCount * 2);
        return RedirectToAction("Dashboard");
    }


    [HttpPost("random")]
    public IActionResult Random()
    {
        Random random = new Random();
        int randomNumber = random.Next(1, 1776);

        int currentCount = HttpContext.Session.GetInt32("Count") ?? 22;
        HttpContext.Session.SetInt32("Count", currentCount + randomNumber);
        return RedirectToAction("Dashboard");

    }


    [HttpGet("dashboard")]
    public ViewResult Dashboard()
    {
        String? Name = HttpContext.Session.GetString("Name");
        if (Name == null)
        {
            return View("Index");
        }
        int? currentCount = HttpContext.Session.GetInt32("Count") ?? 22;
        ViewBag.Count = currentCount;
        return View();
    }


    [HttpPost("logout")]
    public IActionResult Logout()
    {
        HttpContext.Session.Clear();
        return RedirectToAction("Index");
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
