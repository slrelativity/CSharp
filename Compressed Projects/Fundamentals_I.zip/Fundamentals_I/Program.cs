﻿//#1
// int start = 1;
// int end = 255;
// // loop from start to end including end
// for (int i = start; i <= end; i++)
// {
//     Console.WriteLine(i);
// }




// #2
// Random rand = new();

// for (int i = 10; i <= 14; i++)
// {
//     int randomNumber = rand.Next(10,20);
//     Console.WriteLine(randomNumber);
// }




// #3
// int sum = 0;
// Random rand = new();

// for (int i = 1; i <= 5; i++)
// {
//     int randomNumber = rand.Next(10,20);
//     sum +=  randomNumber;
// }
//     Console.WriteLine(sum);



//#4
// int start = 0;
// int end = 100;

// for (int i = start; i <= end; i++)
// {
//     if (i % 3 == 0 && i % 5 !=0) 
//     {
//         Console.WriteLine(i);
//     }
//     else if (i % 5 == 0 && i % 3 != 0)
//     {
//     Console.WriteLine(i);
//     }
// }


//#5
// int start = 1;
// int end = 100;

// for (int i = start; i <= end; i++)
// {
//     if (i % 3 == 0) 
//     {
//     Console.WriteLine("Fizz");    
//     }
//     else if (i % 5 == 0)
//     {
//     Console.WriteLine("Buzz");
//     }
// }

//#6
// int start = 1;
// int end = 100;

// for (int i = start; i <= end; i++)
// {
//         if (i % 3 == 0 && i % 5 == 0)
//     {
//         Console.WriteLine("FizzBuzzz");
//     }
// }



