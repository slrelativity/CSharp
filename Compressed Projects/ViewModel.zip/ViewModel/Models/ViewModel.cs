// Disables warning notifications
#pragma warning disable CS8618
namespace  ViewModel;
public class ViewModel
// Adding a ? at the end of the datatype is option to make it "NULL"
{
    public string Names {get;set;}
    public int Numbers  {get;set;}
}